package cn.zbgl.lm.action;

import cn.zbgl.common.CommonAction;

public class TempAction extends CommonAction {

	@Override
	public String getResult() {
		return result;
	}
	
}
