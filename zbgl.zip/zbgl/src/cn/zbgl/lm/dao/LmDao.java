package cn.zbgl.lm.dao;

public interface LmDao {

	void CheckDao();
}
