package cn.zbgl.lm.service;

public interface LmService {
	
	void CheckService();
}
