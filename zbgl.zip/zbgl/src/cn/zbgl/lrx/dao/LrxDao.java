package cn.zbgl.lrx.dao;

public interface LrxDao {
	
	void testDao();
	
}
