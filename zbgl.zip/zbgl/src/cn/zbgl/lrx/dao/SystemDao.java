package cn.zbgl.lrx.dao;

import java.util.List;
import java.util.Map;


import cn.zbgl.bean.Role;
import cn.zbgl.bean.User;
import cn.zbgl.system.vo.DepartmentAndUserList;

public interface SystemDao {
	void testDao();
}
