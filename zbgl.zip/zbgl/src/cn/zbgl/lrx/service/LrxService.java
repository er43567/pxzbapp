package cn.zbgl.lrx.service;

public interface LrxService {
	
	void testService();
	
	
}
